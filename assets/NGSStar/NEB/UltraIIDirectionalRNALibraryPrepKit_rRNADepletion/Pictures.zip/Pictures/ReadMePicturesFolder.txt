Store within this folder:
All pictures used to perform the process.